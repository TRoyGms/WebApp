import { Component, OnInit } from '@angular/core';
import { Evento } from '../../models/evento';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit {
  eventos: Evento[] = [];

  constructor(private dataService: DataService) {}

  ngOnInit() {
    this.cargarEventos();
  }

  cargarEventos() {
    this.eventos = this.dataService.obtenerEventos();
  }

  editarEvento(evento: Evento) {
    // Lógica para editar evento
  }

  registrarParticipante(evento: Evento) {
    // Lógica para registrar un participante
  }

  eliminarEvento(nombre: string) {
    this.dataService.eliminarEvento(nombre);
    this.cargarEventos(); // Refresca la lista después de eliminar
  }
}
